package com.communication.outboundcallreminder;

public enum CommunicationIdentifierKind {
    UserIdentity, PhoneIdentity, UnknownIdentity
}
